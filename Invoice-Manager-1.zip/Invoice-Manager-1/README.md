# Invoice Manager
- Name: Huijie Ren
- Student Number: 041078506
- Section Number: 302

## 1. What additional code would be required for the Invoice Manager application to accept multiple different file types?
In "accept" attribute there should be more than one file type such as ".pdf",".jpg" and so on.
## 2. How would you improve the Invoice Manager application? What new features would you add or improve?
Users should be allowed to make a payment to change their invoice status.
## 3. What have you learned from completing the Invoice Manager application? How will those skills help you in the future?
I have learned the basic sytan of PHP, control flow, data processing, data validation and session. I also learned how to manage data with databases and manage files with PHP. These could help me build a personal website in the future.

